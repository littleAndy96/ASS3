#pragma once
#include "Item.h"
#include "Inventory.h"
#include "Payment.h"
#include "CashPayment.h"
#include "CreditCardPayment.h"
#include "DebitCardPayment.h"
#include "Time.h"

class Sale
{
public:
	Sale(string date,Time* time, Inventory* inventory);
	~Sale();
	void addItemToSale(Item* item, int quantity);
	void removeItemFromSale(Item*,int);
	double calculateRunningTotalBeforeTaxes();
	double calculateRunningTotalWithTaxes();
	void calculateAmountChargedWithMethod(string method);
	bool completeTransaction();
private:
	Inventory * inventory;
	bool isComplete;
	int id;
	static int idCounter;
	double runningTotalBeforeTaxes; // this is updated every time an items is added or removed
	double runningTotalWithTaxes; // this is updated every time an items is added or removed
	double amountCharged;	// the total amount after taking into account the payment type
	// saleItems is not a dynamically growing array because we did not learn to use vectors yet
	Item** saleItems; // sale is an array of item pointers 
	int numberOfItems;
	static const int maxSaleCapacity = 1000;
	int quantities[maxSaleCapacity] = { 0 };
	string date;
	Time* time;
	Payment* payment;
};

