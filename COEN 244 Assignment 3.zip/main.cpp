// Matt (40074821) Andrew (40054254)

#include "Item.h"
#include "Inventory.h"
#include "Payment.h"
#include "ApprovalAuthority.h"
#include "Sale.h"
#include "Time.h"
#include "Registry.h"
#include <iostream>

using namespace std;

int main() {

	Inventory* inventory = new Inventory();
	Item* item1 = new Item(10011, 6.00, "Watermelon");
	Item* item2 = new Item(10012, 3.50, "Milk");
	Item* item3 = new Item(10013, 4.50, "Bag of bagels");
	Item* item4 = new Item(10014, 2.00, "Candy bar");
	Item* item5 = new Item(10015, 1.00, "Gum");

	cout << "Item 1 price: " << item1->getItemPrice() << endl;
	cout << "Item tax rate: " << item1->getTaxRate() << endl;

	inventory->addItem(item1, 40);
	inventory->itemCheck(item1, 1);
	inventory->addItem(item2, 30);
	inventory->addItem(item3, 10);
	inventory->itemCheck(item2, 1);
	inventory->removeItem(item2, 7);
	inventory->removeItem(item3, 1);
	inventory->addItem(item4, 40);
	inventory->addItem(item5, 49);
	cout << '\n';

	Time* t1 = new Time();
	t1->setTime(12, 55, 20);

	Sale* s1 = new Sale("1 January 2019", t1, inventory);
	s1->addItemToSale(item1, 25);
	s1->addItemToSale(item2, 13);
	s1->removeItemFromSale(item1, 2);
	s1->removeItemFromSale(item2, 1);
	// complete sale
	
	Sale* s2 = new Sale("2 January 2019", t1, inventory);
	s2->addItemToSale(item3, 3);
	s2->addItemToSale(item2, 1);
	s2->removeItemFromSale(item1, 2);
	
	
	Sale* s3 = new Sale("2 January 2019", t1, inventory);
	s3->addItemToSale(item1, 3);
	s3->addItemToSale(item2, 5);
	s3->addItemToSale(item3, 1);
	s3->addItemToSale(item4, 3);
	s3->addItemToSale(item5, 4);

	Sale* s4 = new Sale("3 January 2019", t1, inventory);
	s4->addItemToSale(item1, 2);
	s4->addItemToSale(item2, 1);
	s4->addItemToSale(item3, 3);
	s4->addItemToSale(item4, 3);
	s4->addItemToSale(item5, 2);

	Sale* s5 = new Sale("4 January 2019", t1, inventory);
	s5->addItemToSale(item1, 2);
	s5->addItemToSale(item2, 2);
	s5->addItemToSale(item3, 1);
	s5->addItemToSale(item4, 5);
	s5->addItemToSale(item5, 1);
	


	Registry* r1 = new Registry();
	r1->addCompletedSale(s1);
	r1->addCompletedSale(s2);
	r1->addCompletedSale(s3);
	r1->addCompletedSale(s4);
	r1->addCompletedSale(s5);
	r1->printSummary();

	delete item1;
	delete inventory;

	return 0;
}
