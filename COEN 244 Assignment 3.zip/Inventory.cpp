#include "Inventory.h"
#include "Item.h"
#include <iostream>

/*
I think we should make a new dynamic array for every item we create to make it easier to add and remove
compared to having a large array and just stacking on that
 */

using namespace std;

Inventory::Inventory()
{
	inventory = new Item * [maxCapacity];
	// assign a default Item (id = 0) to all pointers in the array
	for (int i = 0; i < maxCapacity; ++i)
	{
		inventory[i] = new Item(0);
	}
	// the values of the quantities array were already set to 0
	// in the header for inventory class
}


void Inventory::addItem(Item* item, int quantity) {
	// first, look through the array to see if the item is there, in which case we just add to the quantity
	for (int i = 0; i < maxCapacity; ++i) {
		if (inventory[i]->getItemId() == item->getItemId())
		{
			//if id matches, we just add to the quantity of that item
			quantities[i] += quantity;
			return;
		}
	}

	if (numberOfItems == maxCapacity)
	{
		cout << "No more space to add items!\n";
		return;
	}

	// if we exit the for loop, we add the item in next spot and increment numberOfItems
	inventory[numberOfItems] = item;
	++numberOfItems;
}

// if the item is succesfully removed, function returns 1
// if not, return 0
bool Inventory::removeItem(Item* item, int quantity) {	
	for (int i = 0; i < maxCapacity; ++i) {
		if (inventory[i]->getItemId() == item->getItemId())
		{
			// if id matches, we then make sure there's enough quantity to remove
			if (quantities[i] >= quantity)
			{
				quantities[i] -= quantity;
				// finally, if the quantity is now 0, then we remove the item from inventory
				if (quantities[i] == 0)
				{
					inventory[i] = new Item(0); // replace with a default Item

					for (int j = i; j < maxCapacity - 1; ++j)
					{
						inventory[j] = inventory[j + 1];
						quantities[j] = quantities[j + 1];
					}
				}
				return 1;
			}
			// when there is not enough quantity to remove:
			else {
				cout << "You're trying to remove more than we have in stock!\n";
				return 0;
			}
		}
	}

	// here is what happens when the item is not found
	cout << "Item not found!\n";
	return 0;
}

bool Inventory::itemCheck(Item* item, int checkQuantity) {
	for (int i = 0; i < maxCapacity; ++i) {
		if (inventory[i]->getItemId() == item->getItemId()
			/*&& quantities[i] >= checkQuantity*/)
		{
			cout << "Item with ID #" << item->getItemId() << " is found.\n";
			return true;
		}
	}
	// we will return false if we exit the for loop without finding the item
	cout << "Item with ID #" << item->getItemId() << " not found, or not enough quantity.\n";
	return false;
}
