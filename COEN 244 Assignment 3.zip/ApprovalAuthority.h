#pragma once

class ApprovalAuthority
{
public:
	ApprovalAuthority();
	~ApprovalAuthority();
	bool checkApproval();
private:
};
