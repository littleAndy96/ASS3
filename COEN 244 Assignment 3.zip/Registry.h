#pragma once
#include "Sale.h"

class Registry
{
public:
	Registry();
	~Registry();
	void addCompletedSale(Sale* sale);
	void printSummary();
private:
	Sale * * completedSales;
	int numberOfSales;
	int maxNumberOfSales;
};

