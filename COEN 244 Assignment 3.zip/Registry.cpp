#include "Registry.h"



Registry::Registry()
{
	numberOfSales = 0;
	maxNumberOfSales = 500;
	completedSales = new Sale*[maxNumberOfSales];
}


Registry::~Registry()
{

	delete[] completedSales;
}

void Registry::addCompletedSale(Sale * sale)
{
	// check if the sale is completed
	if (sale->completeTransaction() == false)
		return;
	completedSales[numberOfSales] = sale;
	++numberOfSales;
}

void Registry::printSummary()
{
	cout << "\nSummary of all completed sales: \nNumber of sales: "
		<< numberOfSales << '\n';

	double totalSalesBeforeTax = 0;
	for (int i = 0; i < numberOfSales; ++i)
	{
		totalSalesBeforeTax += completedSales[i]->calculateRunningTotalBeforeTaxes();
	}
	cout << "Total value of all sales (before tax): " << totalSalesBeforeTax << '\n';

	double totalSalesAfterTax = 0;
	for (int i = 0; i < numberOfSales; ++i)
	{
		totalSalesAfterTax += completedSales[i]->calculateRunningTotalWithTaxes();
	}

	double totalTax = totalSalesAfterTax - totalSalesBeforeTax;
	cout << "Total tax applied: " << totalTax << '\n';

	cout << "Total value of all sales (after tax): " << totalSalesAfterTax << '\n';
}
